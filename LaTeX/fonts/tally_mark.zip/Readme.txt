This is a guide on using the "Tally Mark" font.

Vertical Line Tallies:

a: one vertical line.
b: two vertical lines.
c: three vertical lines.
d: four vertical lines.
e: diagonal line crossing five vertical lines.
f: horizontal line crossing five vertical lines.

Horizontal Line Tallies:

g: one horizontal line.
h: two horizontal lines.
i: three horizontal lines.
j: four horizontal lines.
k: vertical line crossing four horizontal lines.
l: backslash crossing four horizontal lines.

For more fonts visit:

DaFont: http://www.dafont.com/jhnri4.d3761
FontSpace: http://www.fontspace.com/jlh-fonts